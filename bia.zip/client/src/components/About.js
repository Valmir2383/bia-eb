import { Link } from "react-router-dom";
const About = () => {
  return (
    <div>
      <h4>Versão 2.1.1</h4>
      <h5>BIA EB V3</h5>
      <Link to="/">Voltar</Link>
    </div>
  );
};

export default About;
